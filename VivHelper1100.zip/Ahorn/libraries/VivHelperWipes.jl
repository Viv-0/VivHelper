module VivHelperWipeInject
using ..Ahorn
Ahorn.MetadataWindow.metaDropdownOptions["Wipe"]["Fast Spotlight (Viv's Helper)"] = "VivHelper/FastSpotlight"
end