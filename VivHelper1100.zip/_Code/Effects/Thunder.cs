﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Celeste;
using Celeste.Mod.Entities;
using Monocle;
using Microsoft.Xna.Framework;

namespace VivHelper.Effects {
    [CustomEntity("VivHelper/Thunder")]
    public class Thunder : Backdrop {

    }
}
