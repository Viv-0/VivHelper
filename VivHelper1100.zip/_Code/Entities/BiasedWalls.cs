﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Celeste;
using Monocle;
using Microsoft.Xna.Framework;
using System.Collections;
using System.Reflection;

namespace VivHelper.Entities
{
    public class BiasedWalls : Entity
    {
    }
}
