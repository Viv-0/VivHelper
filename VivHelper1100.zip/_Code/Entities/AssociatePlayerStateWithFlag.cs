﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Celeste;
using Monocle;
using Microsoft.Xna.Framework;

namespace VivHelper.Entities {
    public class AssociatePlayerStateWithFlag : Entity {
        public Dictionary<int, string> stateToFlagDict;

        public AssociatePlayerStateWithFlag(List<EntityData> entityDatas) {

        }
    }

    public class SetDreamingOnFlag : Entity {

    }
}
