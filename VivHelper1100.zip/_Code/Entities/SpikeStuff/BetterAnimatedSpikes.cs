﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Celeste;
using Monocle;
using Celeste.Mod.Entities;
using Microsoft.Xna.Framework;

namespace VivHelper.Entities.SpikeStuff {
    public class BetterAnimatedSpikes : CustomSpike
    {
        private int size;
        private Vector2 offset;
        private PlayerCollider pc;
        private Sprite sprite;
        private Color? color;

        public BetterAnimatedSpikes(EntityData data, Vector2 offset, DirectionPlus dir) : base(data.Position + offset, dir, GetSize(data.Height, data.Width, dir)) {
            base.Depth = -1;
            size = GetSize(data.Height, data.Width, dir);
            offset = offset;
            Add(pc = new PlayerCollider(OnCollide));
            AddTag(Tags.TransitionUpdate);
            var str = data.NoEmptyString("directory", "danger/tentacles");
            var mts = GFX.Game.orig_GetAtlasSubtextures(str + "_" + dir.ToString().ToLower());
            if(mts == null || mts.Count == 0) {
                mts = GFX.Game.GetAtlasSubtextures(str);
            }
            sprite = new Sprite(GFX.Game, str);
            sprite.AddLoop("loop", data.Float("frameDelta", 0.1f), mts.ToArray());
            string c = data.Attr("Color", "White");
            if (c != "Rainbow")
                color = VivHelper.ColorFixWithNull(c) ?? Color.White;
        }

        public override void Added(Scene scene) {
            base.Added(scene);

        }
    }
}
