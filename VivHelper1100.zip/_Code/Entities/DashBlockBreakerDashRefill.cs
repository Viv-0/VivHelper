﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Celeste;
using Monocle;
using Celeste.Mod.Entities;
using Celeste.Mod.VivHelper;
using Microsoft.Xna.Framework;

namespace VivTestMod.Entities
{
    public class DashBlockBreakerDashRefill : Refill
    {

    }
}
