﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Monocle;
using Celeste;
using Celeste.Mod.Entities;
using Microsoft.Xna.Framework;
using MonoMod;
using MonoMod.Utils;
using FMOD.Studio;

namespace VivHelper.Entities.CelesteOnTheMoon {

}
