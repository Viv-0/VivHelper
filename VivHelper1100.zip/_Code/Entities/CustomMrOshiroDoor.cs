﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Celeste;
using Monocle;
using Celeste.Mod.Entities;
using Microsoft.Xna.Framework;

namespace VivHelper.Entities {
    public class CustomMrOshiroDoor : Entity {
        #region Hooks
        public static void Load() {

        }

        public static void Unload() {

        }


        #endregion


    }
}
