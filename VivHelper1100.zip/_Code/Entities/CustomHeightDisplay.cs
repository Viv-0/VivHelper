﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Celeste;
using Monocle;
using Microsoft.Xna.Framework;

namespace VivHelper.Entities {
    public class CustomHeightDisplay : Entity {


        public bool stringMode;
        private int counter = 0;
        public int number;
        public string currentText;


    }
}
