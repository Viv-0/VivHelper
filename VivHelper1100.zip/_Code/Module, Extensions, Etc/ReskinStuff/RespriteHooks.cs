﻿using System;
using System.Collections;
using System.Linq;
using System.Globalization;
using System.Threading;
using System.Reflection;
using Celeste;
using Monocle;
using Microsoft.Xna.Framework;
using Celeste.Mod.Entities;
using Celeste.Mod;
using System.Collections.Generic;
using MonoMod.Cil;
using MonoMod.Utils;
using MonoMod.RuntimeDetour;
using Mono.Cecil.Cil;

namespace VivHelper
{
    public static class ReskinMaster
    {

        public static RespriteBank respriteBank;


    }
}
