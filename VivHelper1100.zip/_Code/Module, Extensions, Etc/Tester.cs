﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Celeste;
using Monocle;
using MonoMod.Utils;
using MonoMod.Cil;
using Mono.Cecil.Cil;
using MonoMod.RuntimeDetour;
using System.Reflection;

namespace VivHelper {
    internal static class Tester {

        public static void Load() {
            
        }

        public static void Unload() {
        }

        
    }
}
