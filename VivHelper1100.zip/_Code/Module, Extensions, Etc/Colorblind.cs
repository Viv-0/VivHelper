﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VivHelper {
    public enum Colorblind {
        Off = 0,
        Protanomaly,
        Protanopia,
        Deuteranomaly,
        Deuteranopia,
        Tritanomaly,
        Tritanopia,
        Achromatopsia
    }
}
